[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/8tTngi_q)
# CS-552 - Milestone 1

Welcome to the MNLP project! For M1, as you can read in the [project description](https://docs.google.com/document/d/1BUeMoBb2zwg1YvO_OnLcqFiXQd8hxiF8ub-cM2MbX_M/edit?usp=sharing), you have 2 main goals: 
1. Collect preference data for 100 questions (individual work)
2. Write literature review (group work)


## Repo Structure

The repo has 6 folders, 2 of which serve for you to submit all three deliverables:
1. `_artifacts` contains the [GPT Wrapper](https://docs.google.com/document/d/1sNZUtlGNyfBfPgYY-nqW07b2jCB850LuX043HJTIJtg/edit?usp=sharing) wheel so you can install it and the annotation UI notebook to help you with the annotation process.
2. `_docs` contains the screenshots used below to explain how to trigger the tests manually.
3. `_templates` contains the latex template for your literature review. You MUST use this template.
4. `_tests` contains some scripts which run automated tests so you can be sure your submission is correctly formatted.
5. `data` should be populated with your collected preference data. You should create a single file for all your 100 questions, name it `<YOUR-SCIPER>.json`. As such, when you submit there should be either 3 or 4 json files in this directory (depending on whether you're a group of 3 or 4).
6. `pdfs` should contain your literature review pdf (titled `<YOUR-GROUP-NAME>.pdf`). This directoty should then have only one pdf.

## Running the tests manually
The autograding tests run automatically with every commit to the repo. If you want to trigger them manually, follow the instructions below:

1. Go to 'Actions' in the top bar
![go to 'Actions' in the top bar](_docs/1.png?raw=true)

2. Click on 'Autograding tests' on the left sidebar
![click on 'Autograding tests' on the left sidebar](_docs/2.png?raw=true)

3. Click on the 'Run workflow' button, next to 'This workflow has a workflow_dispatch event trigger.'
![click on the 'Run workflow' button, next to 'This workflow has a workflow_dispatch event trigger'](_docs/3.png?raw=true)

4. Confirm the test was succesfully passed
![confirm the test was succesfully passed](_docs/4.png?raw=true)

5. If it failed, check the details by clicking on that 'Autograding tests' entry, and then clicking on 'run-autograding-tests'. You can expand the sections to understand where the problem lies.
![you can expand the sections to understand where the problem lies](_docs/5.png?raw=true)

6. Note: if the JSON data validator fails with a `json.decoder.JSONDecodeError: Expecting property name enclosed in double quotes` exception, your JSON has an error that prevents python from loading it in order to verify its format. Like the error indicates, check that the property names are enclosed in double quotes, but also that you don't have trailing commas (e.g., a comma after the last item of a dictionay), as they cause the same exception.
![JSON data validator failing with a json.decoder.JSONDecodeError](_docs/6.png?raw=true)
