import glob

review_pdfs = glob.glob("pdfs/*.pdf")

if len(review_pdfs) < 1:
    print(f'Too few files. You should have 1 joint literature review. (You have {len(review_pdfs)} in total.)')
    exit()
elif len(review_pdfs) > 1:
    print(f'Too many files. You should only have 1 literature review for your group. (You have {len(review_pdfs)} in total.)')
    exit()

print('The literature review exists.')