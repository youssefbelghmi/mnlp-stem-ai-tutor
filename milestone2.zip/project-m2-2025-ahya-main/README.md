[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/w40DsPQE)
# CS-552 - Milestone 2

Welcome to Milestone 2 for the MNLP project! For M2, as you can read in the [project description](https://docs.google.com/document/d/1BUeMoBb2zwg1YvO_OnLcqFiXQd8hxiF8ub-cM2MbX_M/edit?usp=sharing), you have 2 main goals:

1. Post-train the four models detailed in the project description: DPO, MCQA, Quantized-MCQA, RAG-MCQA (individual work, one model per member)
2. Write a progress report (group work)

Note: For M2, you are only graded on whether your models run successfully with our evaluation suite.

## Repo Structure

The repo has 5 folders, 3 of which serve for you to submit all three deliverables:

1. `_templates` contains the LaTeX template for your progress report. You MUST use this template.
2. `_test` contains scripts that run automated tests to validate that your submission is correctly formatted.
3. `model_configs` should be populated by you with the 4 model config YAML files, including `dpo_model.yaml`, `mcqa_model.yaml`, `quantized_model.yaml`, and `rag_model.yaml`. Make sure you fill in the important information in each config file, and the information is exactly what is used for evaluating your models. You need to change `<HF_USERNAME_team_member_X>` to your Huggingface Hub username. Make sure that you have submitted your models to the correct Huggingface Hub repositories, adhering to the following name convention:

- `<HF_USERNAME_team_member_DPO>/MNLP_M2_dpo_model`
- `<HF_USERNAME_team_member_MCQA>/MNLP_M2_mcqa_model`
- `<HF_USERNAME_team_member_QUANTIZED>/MNLP_M2_quantized_model`
- `<HF_USERNAME_team_member_RAG>/MNLP_M2_rag_model`

For the team member responsible for the RAG model, make sure you have submitted the two additional deliverables specific to RAG:

- `<HF_USERNAME_team_member_RAG>/<RAG_DOCUMENT_REPO_NAME>`, replace `<RAG_DOCUMENT_REPO_NAME>` with the actual Huggingface Hub repo name of your submitted RAG documents.
- `<HF_USERNAME_team_member_RAG>/MNLP_M2_document_encoder`

4. `pdf` should be filled by you with your progress report PDF (titled `<YOUR-GROUP-NAME>.pdf`). This directory should then have only one PDF.
5. `data` contains `data_repo.json`. In this file, you need to change `<HF_USERNAME_team_member_X>` to your Huggingface Hub username. Make sure that you have submitted the training data for your 4 models to the correct Huggingface Hub repositories, adhering to the following name convention:

- `<HF_USERNAME_team_member_DPO>/MNLP_M2_dpo_dataset`
- `<HF_USERNAME_team_member_MCQA>/MNLP_M2_mcqa_dataset`
- `<HF_USERNAME_team_member_QUANTIZED>/MNLP_M2_quantized_dataset`
- `<HF_USERNAME_team_member_RAG>/MNLP_M2_rag_dataset`

## Running the tests manually

The autograding tests run automatically with every commit to the repo. If you want to trigger them manually, follow the instructions from the previous milestone.

## Evaluation Suite

For M2, we provide you with an [evaluation suite](https://github.com/eric11eca/lighteval-epfl-mnlp) to benchmark each of the four models. As we covered in the compute tutorial session, details about how we evaluate your models are listed in these slides: [Evaluation Implementation Slides](https://docs.google.com/presentation/d/1SoVY4u6fDgXQ-F6TdarwaINhQ30NnE9Zb2XFavz3PGU/edit?usp=sharing).

We provide you with a demo MCQA evaluation dataset and a demo DPO evaluation dataset on the Huggingface Hub:

- [MCQA demo dataset](https://huggingface.co/datasets/zechen-nlp/MNLP_STEM_mcqa_demo)
- [DPO demo dataset](https://huggingface.co/datasets/zechen-nlp/MNLP_dpo_demo)

Also, for the RAG part, here is a demo Huggingface repo for the RAG documents and a collection of pretrained huggingface embedding models you can start with:

- [RAG documents demo](https://huggingface.co/datasets/m-ric/huggingface_doc)
- [RAG embedding model collection on Huggingface Hub](https://huggingface.co/models?library=sentence-transformers)

## Submission Via Huggingface Hub

Recall that you have to submit your model weights, RAG documents, and training data via [Huggingface Hub](https://huggingface.co/). Make sure you

- Have a Huggingface account.
- Make all your submissions public on the Huggingface Hub.

Please take a look at the documents on how to [upload your dataset](https://huggingface.co/docs/datasets/en/upload_dataset) (documents which are also a dataset) and [upload your model weights](https://huggingface.co/docs/transformers/en/model_sharing#pushtohubmixin). Note that you also have to **push the tokenizers to the same model repository**.

## Validating Your Submission
**After you push your model weights and RAG documents to the correct Huggingface Hub repositories, make sure to test your models with the official [evaluation suite](https://github.com/eric11eca/lighteval-epfl-mnlp) in a fresh and clean environment (not the same environment you used for development).**

**If you got an error in the clean environment, you are responsible for debugging and correcting it.**
