# Reproduce quantized model from fine-tuned MCQA checkpoint

python3 train_quantized.py \
  --model_name "youssefbelghmi/MNLP_M3_mcqa_model_true" \
  --quant_type "nf4" \
  --bit_width 4 \
  --use_double_quant \
  --save_path "quantized_mcqa_model/"
