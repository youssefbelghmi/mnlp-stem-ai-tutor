
import json
import numpy as np
from tqdm import tqdm
# 1. Set up device and move model
import torch
import torch.nn.functional as F
import torch
import torch.nn.functional as F
import torch
from tqdm.auto import tqdm
import pandas as pd
from transformers import AutoTokenizer, AutoModel


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(device)
tokenizer_gte = AutoTokenizer.from_pretrained('Alibaba-NLP/gte-multilingual-base', trust_remote_code = True)
gte_model = AutoModel.from_pretrained('Alibaba-NLP/gte-multilingual-base', trust_remote_code = True).to(device)
gte_model.eval()

# 2. Embedding function that moves data to GPU
def get_gte_embeddings(text):
    # tokenize
    inputs = tokenizer_gte(
        text,
        return_tensors='pt',
        truncation=True,
        padding=True,
        max_length=512
    )
    # move inputs to GPU
    inputs = {k: v.to(device) for k, v in inputs.items()}
    # forward on GPU
    with torch.no_grad():
        outputs = gte_model(**inputs)
    # mean-pool, then move embedding back to CPU if you like
    emb = outputs.last_hidden_state.mean(dim=1)
    return emb.squeeze(0).cpu()  # or .cpu().numpy().tolist()

with open("wiki_chunks.jsonl", "r", encoding="utf-8") as f:
    for line in f:
        wiki_data.append(json.loads(line))

docs_wiki = []
embeddings_wiki = []

for entry in tqdm(wiki_data, desc="Embedding JSON chunks"):
    chunk_text = entry['chunk']
    emb = get_gte_embeddings(chunk_text)
    embeddings_wiki.append(emb)
    
    doc = {
        "text": chunk_text,
        "source": {
            "page_id": entry.get("page_id"),
            "title": entry.get("title")
        }  
    }
    docs_wiki.append(doc)

embeddings_wiki_np = np.vstack(embeddings_wiki).astype('float32')



# 1. Load wiki_data2 from a standard JSON file (list of dicts)
with open("update_corpus.json", "r", encoding="utf-8") as f:
    qgr = json.load(f)

docs_qgr = []
embeddings_qgr= []


# 3. Iterate and build docs + embeddings
for entry in tqdm(qgr, desc="Embedding JSON chunks"):
    chunk_text = entry["chunk"]
    emb = get_gte_embeddings(chunk_text)
    embeddings_qgr.append(emb)

    doc = {
        "text": chunk_text,
        "source": {
            "title": 'from dpo'
        }
    }
    docs_qgr.append(doc)



# 4. Stack embeddings into a NumPy array and save
embeddings_qgr_np = np.vstack(embeddings_qgr).astype("float32")



import numpy as np
import pandas as pd



# 2) Define prefixes that should trigger removal
prefixes_to_remove = [
    ". . . . . . . . . . . . . . . . . . . . . . . . . . . . . .",
    "Title: Just a moment... URL Source: http://stackoverflow.com",
    "Title: Just a moment... URL Source: http://math.stackexchang",
    "Title: The heart of the internet URL Source: http://www.redd",
    "Title: Access to this page has been denied URL Source: http:",
    "Title: Just a moment... URL Source: http://crypto.stackexcha",
    "............................................................",
    "your results more quickly ----------------------------------",
    "● ● ● ● ● ● ● ● ● ● ● ● ● ● ● ● ● ● ● ● ● ● ● ● ● ● ● ● ● ●"
]

# 3) Create a mask for duplicated page_content (keeping only the first occurrence)
mask_duplicate = docs_qgr["text"].duplicated(keep="first")

# 4) Create a mask for page_content that starts with any of the specified prefixes
mask_prefix = docs_qgr["text"].str.startswith(tuple(prefixes_to_remove))

# 5) Combine masks: remove rows that are duplicates OR start with those prefixes
mask_remove = mask_duplicate | mask_prefix

# 6) Determine indices to keep
keep_indices = np.where(~mask_remove)[0]

# 7) Subset both dqgr and embeddings_np_qgr by these indices
docs_qgr = docs_qgr.loc[keep_indices].reset_index(drop=True)
embeddings_qgr_np = embeddings_qgr_np[keep_indices]




combined_df = pd.concat([docs_wiki, docs_qgr], ignore_index=True)

# --- 3) Concatenate the three embedding arrays vertically ---
# Using vstack (or np.concatenate with axis=0) to stack along rows
combined_embeddings = np.vstack([embeddings_wiki_np,embeddings_qgr_np])






# 1) Save the DataFrame to JSON
combined_df.to_json("final_doc.json", orient="records", force_ascii=False, indent=2)

# 2) Save the embeddings array to a .npy file
import numpy as np
np.save("embeddings_final.npy", combined_embeddings)




import faiss
import numpy as np

# Convert embeddings to numpy if needed and ensure float32 dtype



# 3) Standardize all embeddings



# Optional: Normalize embeddings if you want cosine similarity search
# (cosine similarity = inner product if vectors are normalized)
norms = np.linalg.norm(combined_embeddings, axis=1, keepdims=True)
#embeddings_std = embeddings_std / norms.clip(min=1e-10)
combined_embeddings = combined_embeddings / norms.clip(min=1e-10)

# Create FAISS index for inner product (cosine similarity with normalized vectors)
d = combined_embeddings.shape[1]  # 768
index = faiss.IndexFlatIP(d)  # exact search, change if you want approximate

# Add embeddings to index
index.add(combined_embeddings)
print(f"Added {index.ntotal} vectors to FAISS index.")


faiss.write_index(index, "my_faiss_index.faiss")
print("Index saved to 'my_faiss_index.faiss'.")

