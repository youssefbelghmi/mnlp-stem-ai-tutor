import json
import re
from collections import Counter
from cuml.cluster import KMeans as cuKMeans
import cupy
import time
from tqdm import tqdm

word_counter = Counter()
token_pattern = re.compile(r"\b\w+\b", re.UNICODE)


#embeddings_std = embeddings_std.astype('float32')
embeddings_np = np.load('data/embeddings_final.npy')
embeddings_np = embeddings_np.astype('float32')

# Load the dataset from Hugging Face
dataset_rag = load_dataset("Lebossoti/RAG_DOCS")

# Access the first split or the specific one you're interested in
docss = dataset['train']  # Replace 'train' with the actual split name if it's different

docss = json.loads(pd.DataFrame(docss).to_json(orient="records"))
for record in docss:
        text = record.get('text', "")
        # find all word tokens, convert to lower-case
        tokens = token_pattern.findall(text.lower())
        word_counter.update(tokens)




vocabulary = [
    "algorithm", "classification", "regression","linear", "neural", "model", "dataset","predictor",
    "training", "testing", "validation", "clustering", "features", "supervised",
    "unsupervised", "reinforcement", "optimization", "gradient", "deep", "network",
    "convolutional", "backpropagation", "overfitting", "underfitting",
    "regularization", "cross-validation", "hyperparameter", "loss", "activation",
    "dropout", "epoch", "batch", "precision", "recall",
    "cell", "DNA", "protein", "RNA", "gene", "organism", "enzyme", "metabolism",
    "nucleus", "mitochondria", "evolution", "species", "ecology", "genome",
    "transcript", "mutation", "receptor", "membrane", "cytoplasm", "photosynthesis",
    "ribosome", "cytoskeleton", "chloroplast", "glycolysis", "vitamins", "hormone",
    "antibiotic", "antibody", "pathogen", "biodiversity", "homeostasis",
    "symbiosis", "atom", "molecule", "reaction", "bond", "catalyst", "acid", "base", "solvent",
    "compound", "organic", "inorganic", "polymer", "chromatography", "spectroscopy",
    "equilibrium", "kinetics", "thermodynamics", "stoichiometry", "titration",
    "ionic", "pH", "ester", "aldehyde", "amine", "radical", "solubility",
    "viscosity", "conductivity", "nucleophile", "electrophile", "redox",
    "coordination",
    "force", "energy", "mass", "charge", "particle", "quantum", "relativity",
    "field", "wave", "momentum", "gravity", "entropy", "acceleration", "velocity",
    "electron", "photon", "nucleus", "spin", "thermodynamics", "model",
    "curvature", "inertia", "friction", "potential", "kinetic", "plasma",
    "oscillation", "resonance", "superposition", "diffraction", "polarization",
    "gauge",
    "algebra", "geometry", "calculus", "topology", "theorem", "proof", "matrix",
    "vector", "integral", "derivative", "probability", "statistics", "equation",
    "function", "set", "group", "system", "analysis", "model", "variable",
    "combinatorics", "graph", "tensor", "sequence", "series", "limit", "infinity",
    "dimension", "symmetry", "metric", "norm", "basis",
    "algorithm", "data", "program", "complexity", "compiler", "architecture",
    "network", "database", "protocol", "operating", "recursion", "object", "class",
    "interface", "memory", "threading", "security", "encryption", "kernel",
    "distributed", "concurrency", "debugging", "scripting", "framework", "API",
    "cache", "socket", "throughput", "bandwidth", "virtualization", "middleware",
    "sandbox",
    "intelligence", "learning", "agent", "reasoning", "planning", "perception",
    "knowledge", "logic", "robotics", "cognition", "natural", "processing",
    "vision", "translation", "generative", "chatbot", "transformer", "dataset",
    "fairness", "model", "ontology", "semantic", "summarization",
    "interpretability", "heuristic", "search", "Bayesian", "fuzzy", "automation",
    "simulation", "dialogue", "multimodal",
    "design", "system", "analysis", "stress", "structure", "material", "circuit",
    "control", "optimization", "safety", "reliability", "manufacturing", "dynamics",
    "fluid", "instrumentation", "signal", "power", "process", "test", "method",
    "CAD", "finite element", "prototype", "load", "vibration", "tolerance",
    "fabrication", "maintenance", "efficiency", "scalability", "automation",
    "compliance",
    "research", "experiment", "theory", "data", "model", "hypothesis", "analysis",
    "observation", "methodology", "publication", "sample", "measurement",
    "variable", "control", "result", "conclusion", "study", "review",
    "discipline", "framework", "literature", "peer review", "reproducibility",
    "ethics", "paradigm", "meta-analysis", "bias", "survey", "indicator",
    "validation", "replication", "inference",
    "star", "galaxy", "hole",  "cosmology", "planet",
    "orbit", "telescope", "radiation", "spectral", "cluster", "nebula",
    "supernova", "cosmic", "microwave", "redshift", "quasar", "dynamics",
    "pulsar", "accretion", "magnetosphere", "lensing", "cosmic rays",
    "heliosphere", "astroparticle", "neutrino", "extragalactic", "singularity",
    "astrometry", "baryon",
    "allele", "chromosome", "inheritance", "genotype", "phenotype", "sequencing",
    "expression", "linkage", "pedigree", "locus", "epigenetics", "CRISPR",
    "polymorphism", "recombination", "transcriptome", "SNP", "mutation", "genome",
    "regulation", "variation", "heritability", "karyotype", "cytogenetics",
    "transposon", "promoter", "enhancer", "replication", "translation", "codon",
    "intron", "exon", "methylation",
    "ecosystem", "pollution", "climate", "sustainability", "biodiversity",
    "conservation", "habitat", "soil", "water", "renewable", "carbon",
    "footprint", "emission", "monitoring", "restoration", "management", "impact",
    "deforestation", "eutrophication",
    "bioremediation", "greenhouse", "ozone", "acidification", "salinization",
    "contaminant", "urbanization", "sedimentation", "lifecycle", "bioindicator",
    "neuron", "synapse", "brain", "cortex", "neurotransmitter", "signal",
    "plasticity", "circuit", "cognition", "perception", "memory", "behavior",
    "EEG", "fMRI", "hippocampus", "dopamine", "glia", "excitation", "inhibition",
    "network", "axon", "dendrite", "myelin", "action potential", "neurogenesis",
    "amygdala", "thalamus", "basal ganglia", "glutamate", "GABA", "optogenetics",
    "connectome",
    "robot", "actuator", "sensor", "kinematics", "dynamics", "control",
    "autonomy", "SLAM", "manipulation", "planning", "swarm", "humanoid",
    "vision", "odometry", "gripper", "torque", "feedback", "trajectory",
    "algorithm", "simulation", "end effector", "PID", "multi-agent",
    "locomotion", "stability", "mapping", "teleoperation", "haptics", "ROS",
    "inverse kinematics", "calibration", "payload",
    "qubit", "superposition", "entanglement", "decoherence", "gate", "circuit",
    "algorithm", "error", "correction", "measurement", "spin", "coherence",
    "teleportation", "cryptography", "annealing", "simulator", "phase", "Shor",
    "Grover", "register", "unitary", "Hadamard", "QFT", "Bell" , "machine", "CNOT",
    "Toffoli", "Pauli", "topological", "threshold", "quantum supremacy",
    "variational", "quantum volume",
    "composite", "nanomaterial", "polymer", "alloy", "crystal", "fatigue",
    "microstructure", "hardness", "conductivity", "corrosion", "synthesis",
    "characterization", "ceramic", "mechanical", "thermal","wave" , "electromagnetic",
    "optical", "magnetic", "surface", "interface", "elasticity", "tensile",
    "ductility", "fracture", "porosity", "grain boundary", "phase diagram",
    "crystallography", "nanocomposite", "phase transformation", "modulus",
    "alloying",
    "nanoparticle", "nanotube", "graphene", "fabrication", "self-assembly",
    "quantum", "surface", "microscopy", "lithography", "functionalization",
    "drug delivery", "sensor", "nanoscale", "adhesion", "photonic", "carbon",
    "nanoelectronics", "scaffold", "polymer", "device", "cytotoxicity",
    "nanorod", "dendrimer", "biofunctionalization", "nanocarrier",
    "quantum dot", "nanofluid", "AFM", "SEM", "top-down", "bottom-up",
    "surface plasmon",
    "semiconductor", "transistor", "diode", "circuit", "PCB", "oscillator",
    "amplifier", "microcontroller", "signal", "noise", "digital", "analog",
    "VLSI", "filter", "impedance", "current", "voltage", "modulation", "power",
    "board", "FPGA", "ADC", "DAC", "microprocessor", "resistor", "capacitor",
    "inductor", "LED", "photodiode", "OLED", "MEMS", "switching",
    "regression", "estimation", "time series", "panel", "inference", "causality",
    "ARIMA", "cointegration", "heteroskedasticity", "endogeneity",
    "instrumental", "least squares", "likelihood", "variable", "error", "model",
    "data", "hypothesis", "forecast", "test", "vector autoregression (VAR)",
    "GARCH", "quantile regression", "bootstrap", "simulation", "Wald", "test",
    "Hausman" , "multicollinearity", "stationarity",
    "unit root", "structural", "modeling",
    "rock", "mineral", "tectonic", "fault", "sediment", "stratigraphy", "magma",
    "erosion", "crust", "mantle", "core", "plate", "geochemistry",
    "paleontology", "seismology", "volcanic", "metamorphic", "basalt", "quartz",
    "sandstone", "shale", "limestone", "granite", "continental drift", "karst",
    "foliation", "weathering", "alluvial", "ore deposit", "drill core",
    "subduction", "paleoclimate",
    "photometry", "spectroscopy", "exoplanet", "light year", "solar",
    "constellation", "nebula", "pulsar", "dwarf", "observation", "telescope",
    "luminosity", "orbit", "redshift", "stellar", "cluster", "cosmology",
    "galaxy", "dark energy", "supernova", "asteroid", "comet", "meteor",
    "asteroid belt", "Kuiper belt", "Oort cloud", "habitable zone",
    "transit method", "radial velocity", "interferometry", "Hertzsprung-Russell" ,"diagram",
    "sequence", "alignment", "BLAST", "database", "annotation", "transcriptome",
    "proteome", "pipeline", "clustering", "phylogeny", "motif", "expression",
    "variant", "ontology", "normalization", "statistical", "genome", "SNP",
    "algorithm", "query", "next-generation sequencing", "microarray",
    "read mapping", "open reading frame", "differential expression",
    "functional genomics", "protein-protein interaction",
    "structural bioinformatics", "hidden Markov model", "gene ontology",
    "enrichment analysis", "motif discovery"
]


# 1. Filter for freq > 10000, and pair each term with its count
# Option A: chained comparison
vocab_filt = [
    (w, word_counter.get(w, 0))
    for w in vocabulary
    if word_counter.get(w,0)>0
]


# 2. Sort descending by count
vocab_filt.sort(key=lambda x: x[1], reverse=True)



# 3. (Optional) If you want just the words, discard the counts:
filtered_words = [w for w, cnt in set(vocab_filt)]



retained_indices = []
kept=0
for i, doc in enumerate(docss):
    # find the first matching word, or None
    if i%100000==0:
        print(i)
        print(kept)
    match = next((w for w in doc['text'].split() if w in set(filtered_words)), None)
    if match:
        retained_indices.append(i)
        kept+=1

print(kept)

# Build the filtered lists
filtered_docss       = [docss[i] for i in retained_indices]
filtered_embeddings  = embeddings_np[retained_indices]

# (Optional) overwrite your originals
docss               = filtered_docss
embeddings_np       = filtered_embeddings


# Push your (552 946 × 768) array onto GPU once
X_gpu = cupy.asarray(embeddings_np, dtype=cupy.float32)

# Instantiate KMeans with NO oversampling:
#  • init="random" ensures no k-means++ or k-means|| sampling
#  • max_samples_per_batch controls your mini-batch size
kmeans = cuKMeans(
    n_clusters=170_000,
    init="random",           # RANDOM init: zero oversampling
    max_iter=20,             # fewer passes to convergence
    n_init=1,                # just one start → no extra restarts
    tol=1e-3,                # stop early if centers move <0.1%
    verbose=True,            # log progress per iteration
    max_samples_per_batch=10_000,  # your “batch_size”
    # note: we simply omit oversampling_factor entirely
)

kmeans.fit(X_gpu)


labels = kmeans.labels_         # cupy array of shape (N,)
centroids = kmeans.cluster_centers_  # cupy array of shape (K, D)



d = centroids_np.shape[1]
batch_size = 1024  # tune this up/down to balance speed vs. memory
all_I = np.empty((centroids_np.shape[0], 1), dtype=np.int64)
all_D = np.empty((centroids_np.shape[0], 1), dtype=np.float32)

for start in tqdm(range(0, centroids_np.shape[0], batch_size), 
                  desc="Finding reps"):
    end = min(start + batch_size, centroids_np.shape[0])
    D_batch, I_batch = index.search(centroids_np[start:end], 1)
    all_D[start:end] = D_batch
    all_I[start:end] = I_batch

# now:
Dists = all_D   # (K,1)
I     = all_I   # (K,1)


rep_idxs = I.ravel()  # shape (K,)

# 2) Get the embeddings for those indices
rep_embeddings = embeddings_np[rep_idxs]      # shape (K, D)

# 3) Get the docs for those indices
rep_docs = [docss[i] for i in rep_idxs]        # list of length K

# Save embeddings
np.save('data/embeddings_small.npy', rep_embeddings)
print("Saved embeddings to data/embeddings_small.npy →", rep_embeddings.shape)

# Save documents as JSON
with open('data/docs_small.json', 'w', encoding='utf-8') as f:
    json.dump(rep_docs, f, ensure_ascii=False, indent=2)
print("Saved documents to data/docs_small.json →", len(rep_docs))


with open("data/docs_small.json", "r", encoding="utf-8") as infile:
    records = json.load(infile)
df_temp = pd.DataFrame(records)
df_temp['source'] = df_temp['source'].astype(str)

# Convert the DataFrame to JSONL (JSON Lines format)
jsonl_output = df_temp.to_json(orient='records', lines=True)

# Save as a .jsonl file for better converting in DataSet HF
output_path = 'docs_small.jsonl'  
with open(output_path, 'w') as file:
    file.write(jsonl_output)

