import requests
import json
from datasets import load_dataset
from tqdm.auto import tqdm
import os



# ──────────────────────────────────────────────────────────────────────────────
# 1. MEDIAWIKI → get all page IDs for a set of categories at depth 2
# ──────────────────────────────────────────────────────────────────────────────

WIKI_API = "https://en.wikipedia.org/w/api.php"

def fetch_category_members(category, cmtype, cmcontinue=None):
    """
    Helper to call MediaWiki API 'categorymembers'.
    """
    params = {
        "action": "query",
        "format": "json",
        "list": "categorymembers",
        "cmtitle": f"Category:{category}",
        "cmtype": cmtype,       # "page" or "subcat"
        "cmlimit": "max",
    }
    if cmcontinue:
        params["cmcontinue"] = cmcontinue

    r = requests.get(WIKI_API, params=params)
    r.raise_for_status()
    data = r.json()["query"]["categorymembers"]
    next_token = r.json().get("continue", {}).get("cmcontinue")
    return data, next_token

def gather_page_ids_from_category(cat, max_depth=2):
    """
    Recursively collects all 'page' members under `cat` 
    and (if depth > 0) walks subcategories.
    """
    pages = set()
    seen_cats = set([cat])
    to_visit = [(cat, 0)]

    while to_visit:
        current_cat, depth = to_visit.pop(0)
        # -- get direct pages --
        cont = None
        while True:
            members, cont = fetch_category_members(current_cat, cmtype="page", cmcontinue=cont)
            pages |= {m["pageid"] for m in members}
            if not cont:
                break

        # -- recurse into subcategories if depth < max_depth --
        if depth < max_depth:
            cont = None
            while True:
                members, cont = fetch_category_members(current_cat, cmtype="subcat", cmcontinue=cont)
                for m in members:
                    subcat = m["title"].replace("Category:", "")
                    if subcat not in seen_cats:
                        seen_cats.add(subcat)
                        to_visit.append((subcat, depth + 1))
                if not cont:
                    break

    return pages

def gather_all_ids(categories, depth=2):
    all_ids = set()
    for cat in categories:
        print(f"→ walking Category:{cat} up to depth {depth}")
        page_ids = gather_page_ids_from_category(cat, max_depth=depth)
        print(f"   found {len(page_ids)} pages under {cat}")
        all_ids |= page_ids
    return all_ids


# ──────────────────────────────────────────────────────────────────────────────
# 2. Load HF Wikipedia, filter by IDs, chunk into ~300-word passages
# ──────────────────────────────────────────────────────────────────────────────

def fetch_pages_by_id(batch_ids):
    """
    Fetch plain-text extracts for up to 50 page IDs at once.
    Returns a list of page dicts.
    """
    params = {
        "action": "query",
        "format": "json",
        "prop": "extracts",
        "explaintext": 1,
        "pageids": "|".join(str(i) for i in batch_ids)
    }
    r = requests.get(WIKI_API, params=params)
    r.raise_for_status()
    pages = r.json()["query"]["pages"]
    return list(pages.values())

def fetch_page_by_id(page_id):
    """
    Wrapper to fetch a single page ID and return its dict.
    """
    pages = fetch_pages_by_id([page_id])
    return pages[0]  # unpack the single-item list
    
def chunk_text(text, chunk_size=300):
    words = text.split()
    for i in range(0, len(words), chunk_size):
        yield " ".join(words[i : i + chunk_size])

def process_wikipedia(page_ids, output_path="wiki_chunks.jsonl", chunk_size=300):
    ds = load_dataset("wikipedia", "20220301.en", split="all")
    with open(output_path, "w", encoding="utf-8") as writer:
        for ex in tqdm(ds, desc="Wiki ▶ filter & chunk"):
            if ex["id"] in page_ids:
                for chunk in chunk_text(ex["text"], chunk_size=chunk_size):
                    record = {
                        "page_id": ex["id"],
                        "title": ex["title"],
                        "chunk": chunk
                    }
                    writer.write(json.dumps(record, ensure_ascii=False) + "\n")
    size_gb = os.path.getsize(output_path) / 1e9
    print(f"Wrote Wikipedia chunks: {size_gb:.3f} GB")



# ──────────────────────────────────────────────────────────────────────────────
# 4. Main
# ──────────────────────────────────────────────────────────────────────────────


# --- Main loop: one-by-one fetching ---

if __name__ == "__main__":
    categories = [
        "Machine learning",
        "Biology",
        "Chemistry",
        "Physics",
        "Mathematics",
        "Computer science",
        "Artificial intelligence",
        "Engineering",
        "Sciences",
        "Astrophysics",
        "Genetics",
        "Environmental science",
        "Neuroscience",
        "Robotics",
        "Quantum computing",
        "Materials science",
        "Nanotechnology",
        "Electronics",
        "Econometrics",
        "Geology",
        "Astronomy",
        "Bioinformatics"
    ]


    page_ids = gather_all_ids(categories, depth=2)
    print(f"Total unique Wikipedia pages: {len(page_ids)}")
    page_ids = list(set(page_ids))  # your precomputed list/set of IDs
    
    process_wikipedia(page_ids, output_path="wiki_chunks.jsonl", chunk_size=300)

