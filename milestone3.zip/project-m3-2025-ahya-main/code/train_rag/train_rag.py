#!/usr/bin/env python3

import json
import faiss
import numpy as np
import torch
from tqdm.auto import tqdm

from datasets import load_dataset
from transformers import (
    AutoTokenizer,
    AutoModel,
    AutoModelForCausalLM,
    AutoConfig,
)
from transformers.models.auto.modeling_auto import MODEL_FOR_IMAGE_TEXT_TO_TEXT_MAPPING_NAMES

from trl import (
    ModelConfig,
    ScriptArguments,
    SFTConfig,
    SFTTrainer,
    TrlParser,
    get_kbit_device_map,
    get_peft_config,
    get_quantization_config,
    setup_chat_format,
)

# ────────────────────────────────────────────────────────────────────────────────
# 1) Load document metadata (JSON) and precomputed embeddings; build FAISS index
# ────────────────────────────────────────────────────────────────────────────────

import pandas as pd
from datasets import load_dataset
import json

# Load the dataset from Hugging Face
dataset_rag = load_dataset("Lebossoti/RAG_DOCS")

# Access the first split or the specific one you're interested in
docss = dataset['train']  # Replace 'train' with the actual split name if it's different

docss = json.loads(pd.DataFrame(docss).to_json(orient="records"))

import faiss
import numpy as np
import os



index_path = "index.faiss"

# Check if the index file exists
if os.path.exists(index_path):
    # If it exists, load the index from the file
    index = faiss.read_index(index_path)
    print(f"Loaded FAISS index from '{index_path}', contains {index.ntotal} vectors.")
else:
    # If it doesn't exist, create a new index and add embeddings
    if os.path.exists('data/embeddings_final.npy'):
        embeddings_np = np.load("data/embeddings_final.npy")
        embeddings_np = embeddings_np.astype("float32")

    else:
        embeddings = []

        for entry in tqdm(docss, desc="Embedding JSON chunks"):
            chunk_text = entry['text']
            emb = get_gte_embeddings(chunk_text)
            embeddings.append(emb)
    

        embeddings_np = np.vstack(embeddings_test).astype('float32')
        
    
    # Normalize embeddings (for inner-product cosine search)
    norms = np.linalg.norm(embeddings_np, axis=1, keepdims=True)
    embeddings_np = embeddings_np / norms.clip(min=1e-10)
    d = embeddings_np.shape[1]  # embedding dimension (e.g. 768)
    index = faiss.IndexFlatIP(d)  # exact inner-product index
    index.add(embeddings_np)
    print(f"Added {index.ntotal} vectors to FAISS index.")
    
    # Save the newly created index
    faiss.write_index(index, index_path)
    print(f"FAISS index saved to '{index_path}'.")


# ────────────────────────────────────────────────────────────────────────────────
# 2) Load GTE embedding model for retrieval
# ────────────────────────────────────────────────────────────────────────────────

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

tokenizer_gte = AutoTokenizer.from_pretrained("Alibaba-NLP/gte-multilingual-base", trust_remote_code = True)
gte_model = AutoModel.from_pretrained("Alibaba-NLP/gte-multilingual-base", trust_remote_code = True).to(device)
gte_model.eval()

def get_gte_embeddings(text: str) -> torch.Tensor:
    """
    Returns a 1×D embedding for the input text using GTE (mean-pooled), moved back to CPU.
    """
    inputs = tokenizer_gte(
        text,
        return_tensors="pt",
        truncation=True,
        padding=True,
        max_length=512,
    )
    inputs = {k: v.to(device) for k, v in inputs.items()}
    with torch.no_grad():
        outputs = gte_model(**inputs)
    emb = outputs.last_hidden_state.mean(dim=1)  # [1, D]
    return emb.squeeze(0).cpu()

# ────────────────────────────────────────────────────────────────────────────────
# 3) Retrieval functions: search + context formatting
# ────────────────────────────────────────────────────────────────────────────────

def search(query_text: str, k: int = 5):
    """
    Given a query string, retrieve the top-k documents from the FAISS index.
    Returns a list of (doc, score) tuples.
    """
    query_emb = get_gte_embeddings(query_text)  # torch.Tensor [D]
    query_np = query_emb.numpy().astype("float32")
    query_np /= np.linalg.norm(query_np, axis=-1, keepdims=True)
    query_np = query_np.reshape(1, -1)

    distances, indices = index.search(query_np, k)
    results = []
    for score, idx in zip(distances[0], indices[0]):
        doc = docss[idx]
        results.append((doc, float(score)))
    return results

def bring_context_string(res):
    """
    Given res = list of (doc, score) tuples, build a single context string containing
    truncated page_content from each retrieved doc.
    """
    context_pieces = []
    for i, (doc, score) in enumerate(res, start=1):
        snippet = doc["text"].replace("\n", " ")
        context_pieces.append(f"context {i} : {snippet}\n")

    full_context = (
        "Here is some useful context that will help you to answer this question:\n\n"
        + "\n".join(context_pieces)
        + "\n"
    )
    return full_context

# ────────────────────────────────────────────────────────────────────────────────
# 4) Preprocessing: build each MCQA prompt + retrieved context
# ────────────────────────────────────────────────────────────────────────────────

def preprocess(example):
    """
    Build a prompt for multiple-choice QA that includes:
      1) A fixed introduction line
      2) Retrieved context (via search + bring_context_string)
      3) The question and its choices
      4) The "Answer:" suffix
    Returns a dict with keys "prompt" and "completion".
    """
    # Map indices to letters
    letter_map = {0: "A", 1: "B", 2: "C", 3: "D"}
    options = "\n".join(
        [f"{letter_map[i]}. {opt}" for i, opt in enumerate(example["choices"])]
    )
    explanation = (example.get("support") or "").strip()
    explanation_text = f"Explanation: {explanation}\n" if explanation else ""

    # Retrieve and format context
    context_text = bring_context_string(search(example["question"]))

    # Concatenate into one string for the prompt

    prompt = (
        "The following is a multiple-choice question (with answers) about knowledge and skills in advanced master's-level STEM fields.\n"
        "You will be provided with an explanation to help you understand the correct answer.\n"
        + context_text
        +"Select the correct answer by replying with the option letter (A, B, C, or D) only.\n\n"
        +f"Question: {example['question']}\n"
        +f"{options}\n"
        +f"{explanation_text}"
        +"Answer:"
    )

    # Return separate fields: "prompt" and "completion"
    return {"prompt": prompt, "completion": f" {example['answer']}"}

# ────────────────────────────────────────────────────────────────────────────────
# 5) Main training entrypoint using TRL's SFTTrainer (subsetting for a small sample)
# ────────────────────────────────────────────────────────────────────────────────

def main(script_args, training_args, model_args):
    # 5.1) Quantization / device_map (if requested)
    quantization_config = get_quantization_config(model_args)
    model_kwargs = dict(
        revision=model_args.model_revision,
        trust_remote_code=model_args.trust_remote_code,
        attn_implementation=model_args.attn_implementation,
        torch_dtype=torch.bfloat16,
        use_cache=False if training_args.gradient_checkpointing else True,
        device_map=get_kbit_device_map() if quantization_config is not None else None,
        quantization_config=quantization_config,
    )

    # 5.2) Load model config and choose correct class
    config = AutoConfig.from_pretrained(model_args.model_name_or_path)
    valid_image_text_architectures = MODEL_FOR_IMAGE_TEXT_TO_TEXT_MAPPING_NAMES.values()

    if config.architectures and any(
        arch in valid_image_text_architectures for arch in config.architectures
    ):
        from transformers import AutoModelForImageTextToText

        model_kwargs.pop("use_cache", None)
        model = AutoModelForImageTextToText.from_pretrained(
            model_args.model_name_or_path, **model_kwargs
        )
    else:
        model = AutoModelForCausalLM.from_pretrained(
            model_args.model_name_or_path, **model_kwargs
        )

    # 5.3) Load tokenizer (with chat formatting if needed)
    tokenizer = AutoTokenizer.from_pretrained(
        model_args.model_name_or_path,
        trust_remote_code=model_args.trust_remote_code,
        use_fast=True,
    )
    if tokenizer.chat_template is None:
        model, tokenizer = setup_chat_format(model, tokenizer, format="chatml")

    # 5.4) Load full dataset and then subset to a small sample
    dataset_full = load_dataset(script_args.dataset_name)

    train_split = dataset_full[script_args.dataset_train_split]
    eval_split  = dataset_full[script_args.dataset_test_split] if training_args.eval_strategy != "no" else None

    train_dataset = train_split.map(preprocess, remove_columns=train_split.column_names)
    eval_dataset  = eval_split.map(preprocess, remove_columns=eval_split.column_names) if eval_split is not None else None

    # 5.5) Initialize SFTTrainer with completion_only=True (no formatting_func)
    trainer = SFTTrainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset if training_args.eval_strategy != "no" else None,
        peft_config=get_peft_config(model_args)  # compute loss only on the "completion" tokens
    )

    # 5.6) Train & save
    trainer.train()
    trainer.save_model(training_args.output_dir)

    # 5.7) Push to Hugging Face Hub if requested
    if training_args.push_to_hub:
        trainer.push_to_hub(dataset_name=script_args.dataset_name)


def make_parser(subparsers=None):
    """
    Build a single parser that merges ScriptArguments, SFTConfig, and ModelConfig.
    """
    dataclass_types = (ScriptArguments, SFTConfig, ModelConfig)
    if subparsers is not None:
        parser = subparsers.add_parser(
            "sft", help="Run the SFT training script", dataclass_types=dataclass_types
        )
    else:
        parser = TrlParser(dataclass_types)
    return parser


if __name__ == "__main__":
    parser = make_parser()
    script_args, training_args, model_args = parser.parse_args_into_dataclasses()
    main(script_args, training_args, model_args)
