from tqdm.auto import tqdm
import time
tqdm.pandas()  # register the “progress_apply” method with pandas

# Make sure `key` and `cx` are defined before running this.
# e.g.:
# key = "YOUR_API_KEY"
# cx  = "YOUR_CSE_ID"

import json

import requests
import time
from urllib.parse import urlparse
import pandas as pd
import numpy as np
import os



def search( query, **kwargs):
        """
        Perform a Google Custom Search query.
        
        Args:
            query (str): Search query
            **kwargs: Additional parameters for the search API
            
        Returns:
            list: List of search results
        """
        if not query:
            return []
            
        url = 'https://www.googleapis.com/customsearch/v1'
        params = {
            'q': query,
            # Your Custom Search Engine ID and API Key
            'key': 'KEY',
            'cx': 'CSEID',
            'num': 3  # Limit to 1 result to save quota
        }
        params.update(kwargs)  # Add any additional parameters
        
        try:
            response = requests.get(url, params=params)
            
            if response.status_code == 403:
                print("API Error: 403 Forbidden. Please check your API key and CSE ID.")
                return []
            elif response.status_code == 429:
                print("API Error: 429 Too Many Requests. Please wait before trying again.")
                return []
                
            response.raise_for_status()
            results = response.json()
            return results.get('items', [])
            
        except requests.exceptions.RequestException as e:
            print(f"Error during Google search: {str(e)}")
            return []
    


    

def get_top3_links(query):
    """
    Run a Google Custom Search for `query` and return a tuple of
    (link1, link2, link3), using None for any missing slots.
    """
    if not query or not isinstance(query, str):
        return (None, None, None)

    items = search(query, num=3)  # returns a list of up to 3 items
    urls = []
    for item in items[:3]:
        url = item.get("link")
        if url:
            urls.append(url)

    # Pad with None so we always return exactly three elements
    while len(urls) < 3:
        urls.append(None)

    time.sleep(0.5)  # Sleep to avoid hitting API rate limits too quickly

    return (urls[0], urls[1], urls[2])

from bs4 import BeautifulSoup
import requests
def get_text(url):
        """
        Extract text content from a URL.
        
        Args:
            url (str): URL to extract text from
            
        Returns:
            Optional[str]: Extracted text content or None if failed
        """
        if not url or not isinstance(url, str):
            return None
        try:
            response = requests.get(url)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, "html.parser")
            text = soup.get_text()
            return text
        except Exception:
            print(f"Failed to fetch or parse URL: {url}")
            return None

def chunk_text(text, chunk_size=300):
    """
    Split a string into chunks of up to `chunk_size` words.
    Returns a list of text‐chunks.
    """
    if not isinstance(text, str):
        return []
    
    words = text.split()
    chunks = []
    for i in range(0, len(words), chunk_size):
        chunk = " ".join(words[i : i + chunk_size])
        chunks.append(chunk)
    return chunks

pfdf = pd.read_json('data/questions.json')
# Copy the DataFrame
df_test = pfdf.copy()

# Use `.progress_apply(...)` instead of `.apply(...)` to get a tqdm progress bar.
link_cols = df_test["question"].progress_apply(get_top3_links)

# Split the resulting tuples into three separate columns
df_test[["link1", "link2", "link3"]] = pd.DataFrame(link_cols.tolist(), index=df_test.index)

#if link starts with http:// => replace with https://
df_test['link1'] = df_test['link1'].apply(lambda x: x.replace('http://', 'https://') if isinstance(x, str) and x.startswith('http://') else x)
df_test['link2'] = df_test['link2'].apply(lambda x: x.replace('http://', 'https://') if isinstance(x, str) and x.startswith('http://') else x)
df_test['link3'] = df_test['link3'].apply(lambda x: x.replace('http://', 'https://') if isinstance(x, str) and x.startswith('http://') else x)

df_test['proc_link1']= df_test['link1'].apply(lambda x: x.replace('https://', 'https://r.jina.ai/') if isinstance(x, str) and x.startswith('https://') else x)
df_test['proc_link2']= df_test['link2'].apply(lambda x: x.replace('https://', 'https://r.jina.ai/') if isinstance(x, str) and x.startswith('https://') else x)
df_test['proc_link3']= df_test['link3'].apply(lambda x: x.replace('https://', 'https://r.jina.ai/') if isinstance(x, str) and x.startswith('https://') else x)


        

df_test['text1'] = df_test['proc_link1'].progress_apply(get_text)
df_test['text2'] = df_test['proc_link2'].progress_apply(get_text)
df_test['text3'] = df_test['proc_link3'].progress_apply(get_text)


#if any of text1, text2, text3 start with 'Title: Just a moment' => replace it with None
df_test['text1'] = df_test['text1'].apply(lambda x: None if isinstance(x, str) and x.startswith('Just a moment') else x)
df_test['text2'] = df_test['text2'].apply(lambda x: None if isinstance(x, str) and x.startswith('Just a moment') else x)
df_test['text3'] = df_test['text3'].apply(lambda x: None if isinstance(x, str) and x.startswith('Just a moment') else x)


# Build a list of {"source": ..., "chunk": ...} entries with tqdm progress
output_list = []

for _, row in tqdm(df_test.iterrows(), total=len(df_test), desc="Processing rows"):
    for col in ['text1', 'text2', 'text3']:
        text = row[col]
        if isinstance(text, str):
            for chunk in chunk_text(text, chunk_size=300):
                output_list.append({
                    "source": row['question_id'],
                    "chunk": chunk
                })

# Convert to JSON
json_output = json.dumps(output_list, ensure_ascii=False, indent=2)

# Save to a JSON file
with open("update_corpus.json", "w", encoding="utf-8") as f:
    f.write(json_output)

# Show how many chunks were created in total
print(f"Total chunks created: {len(output_list)}")
