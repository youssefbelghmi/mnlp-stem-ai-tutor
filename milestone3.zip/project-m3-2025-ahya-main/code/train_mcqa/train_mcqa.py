"""
# Full training
python train_mcqa/train_mcqa.py \
    --model_name_or_path tocico28/MNLP_M3_dpo_model \
    --dataset_name youssefbelghmi/MNLP_M3_mcqa_dataset \
    --dataset_train_split train \
    --dataset_test_split validation \
    --learning_rate 2e-5 \
    --num_train_epochs 1 \
    --per_device_train_batch_size 4 \
    --per_device_eval_batch_size 4 \
    --gradient_accumulation_steps 4 \
    --gradient_checkpointing \
    --eos_token '<|im_end|>' \
    --eval_strategy steps \
    --eval_steps 100 \
    --logging_steps 100 \
    --output_dir MNLP_M3_mcqa_model \
    --trust_remote_code \
    --push_to_hub
"""

import torch

import argparse

from datasets import load_dataset

from transformers import AutoTokenizer, AutoModelForCausalLM, AutoConfig

from transformers.models.auto.modeling_auto import MODEL_FOR_IMAGE_TEXT_TO_TEXT_MAPPING_NAMES

from trl import (
    ModelConfig,
    ScriptArguments,
    SFTConfig,
    SFTTrainer,
    TrlParser,
    get_kbit_device_map,
    get_peft_config,
    get_quantization_config,
    setup_chat_format,
)

def preprocess(example):
    letter_map = {0: "A", 1: "B", 2: "C", 3: "D"}
    options = "\n".join([f"{letter_map[i]}. {opt}" for i, opt in enumerate(example["choices"])])

    explanation = (example.get("support") or "").strip()
    explanation_text = f"Explanation: {explanation}\n" if explanation else ""

    prompt = (
        "The following is a multiple-choice question (with answers) about knowledge and skills in advanced master's-level STEM fields.\n"
        "You will be provided with an explanation to help you understand the correct answer.\n"
        "Select the correct answer by replying with the option letter (A, B, C, or D) only.\n\n"
        f"Question: {example['question']}\n"
        f"{options}\n"
        f"{explanation_text}"
        "Answer:"
    )

    return {
        "prompt": prompt,
        "completion": f" {example['answer']}"
    }

def main(script_args, training_args, model_args):
    quantization_config = get_quantization_config(model_args)
    model_kwargs = dict(
        revision=model_args.model_revision,
        trust_remote_code=model_args.trust_remote_code,
        attn_implementation=model_args.attn_implementation,
        torch_dtype=torch.bfloat16,
        use_cache=False if training_args.gradient_checkpointing else True,
        device_map=get_kbit_device_map() if quantization_config is not None else None,
        quantization_config=quantization_config,
    )

    config = AutoConfig.from_pretrained(model_args.model_name_or_path)
    valid_image_text_architectures = MODEL_FOR_IMAGE_TEXT_TO_TEXT_MAPPING_NAMES.values()

    if config.architectures and any(arch in valid_image_text_architectures for arch in config.architectures):
        from transformers import AutoModelForImageTextToText
        model_kwargs.pop("use_cache", None)
        model = AutoModelForImageTextToText.from_pretrained(model_args.model_name_or_path, **model_kwargs)
    else:
        model = AutoModelForCausalLM.from_pretrained(model_args.model_name_or_path, **model_kwargs)

    tokenizer = AutoTokenizer.from_pretrained(
        model_args.model_name_or_path, trust_remote_code=model_args.trust_remote_code, use_fast=True
    )

    if tokenizer.chat_template is None:
        model, tokenizer = setup_chat_format(model, tokenizer, format="chatml")

    dataset = load_dataset(script_args.dataset_name)
    dataset = dataset.map(preprocess)

    trainer = SFTTrainer(
        model=model,
        args=training_args,
        train_dataset=dataset[script_args.dataset_train_split],
        eval_dataset=dataset[script_args.dataset_test_split] if training_args.eval_strategy != "no" else None,
        formatting_func=lambda example: f"{example['prompt']}{example['completion']}",
        peft_config=get_peft_config(model_args),
    )

    trainer.train()
    trainer.save_model(training_args.output_dir)
    if training_args.push_to_hub:
        trainer.push_to_hub(dataset_name=script_args.dataset_name)

def make_parser(subparsers: argparse._SubParsersAction = None):
    dataclass_types = (ScriptArguments, SFTConfig, ModelConfig)
    if subparsers is not None:
        parser = subparsers.add_parser("sft", help="Run the SFT training script", dataclass_types=dataclass_types)
    else:
        parser = TrlParser(dataclass_types)
    return parser

if __name__ == "__main__":
    parser = make_parser()
    script_args, training_args, model_args, _ = parser.parse_args_and_config(return_remaining_strings=True)
    main(script_args, training_args, model_args)
