import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
import argparse
import os

# Argument parsing for command-line arguments
parser = argparse.ArgumentParser()
parser.add_argument("--model_name", type=str, required=True)
parser.add_argument("--quant_type", type=str, choices=["nf4", "fp4"], default="nf4")
parser.add_argument("--bit_width", type=int, choices=[4, 8], default=4)
parser.add_argument("--use_double_quant", action="store_true")
parser.add_argument("--save_path", type=str, required=True)
args = parser.parse_args()

# Load tokenizer (tokenizer should be consistent with the model)
tokenizer = AutoTokenizer.from_pretrained(args.model_name)

# Set up the quantization configuration
if args.bit_width == 8:
    quant_config = BitsAndBytesConfig(
        load_in_8bit=True,
        llm_int8_enable_fp32_cpu_offload=True
    )
else:
    quant_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type=args.quant_type,  # Can be "nf4" or "fp4"
        bnb_4bit_use_double_quant=args.use_double_quant
    )

# Load the model with the specified quantization configuration
model = AutoModelForCausalLM.from_pretrained(
    args.model_name,
    quantization_config=quant_config,
    device_map="auto"  # Automatically place model on available device
)
model.eval()

# Create directory to save quantized model and tokenizer
os.makedirs(args.save_path, exist_ok=True)

# Save the model and tokenizer to the specified directory for reproducibility
tokenizer.save_pretrained(args.save_path)
model.config.save_pretrained(args.save_path)

print(f"Quantized model saved to {args.save_path}")
